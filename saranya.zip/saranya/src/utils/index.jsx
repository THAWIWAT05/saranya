export { default as AnimatedSection } from "./AnimatedSection.jsx";
